# RefugeOS automatic installer v7

This version fixes two issues from v6:

- it starts logging **after** root escalation, so `/var/log/refugeos-auto-install.log` no longer throws a permission error.
- it no longer tries to prefetch large packages into the small live USB root. It partitions and mounts the target disk first, then prefetches bootstrap and payload packages into **`/mnt/var/cache/pacman/pkg`** on the target disk.

It also filters out `zram`, `loop`, and `ram` pseudo-disks from the target disk menu and uses a direct multi-mirror list before the geo mirror.

Run:

```bash
chmod +x install-refugeos-auto-standalone-v7.sh
sudo ./install-refugeos-auto-standalone-v7.sh
```

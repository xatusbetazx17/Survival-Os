#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
PACKAGE_FILE_DEFAULT="${SCRIPT_DIR}/refugeos-packages.txt"
PACKAGE_FILE="${REFUGE_PACKAGE_FILE:-}"
PACKAGE_SOURCE=""
CONFIG_FILE="${REFUGE_CONFIG_FILE:-${SCRIPT_DIR}/refugeos-install.conf}"
LOG_FILE="/var/log/refugeos-auto-install.log"
TARGET_ROOT="/mnt"
WORK_DIR="/tmp/refugeos-auto-install"
ARCH_CFG="${WORK_DIR}/archinstall-config.json"
ARCH_CREDS="${WORK_DIR}/archinstall-creds.json"
PKG_LIST_FILE="${WORK_DIR}/install-packages.txt"
LIVE_PACMAN_CONF_BACKUP="/tmp/refugeos-pacman.conf.bak"

mkdir -p "${WORK_DIR}"

if [[ -f "${CONFIG_FILE}" ]]; then
  # shellcheck disable=SC1090
  source "${CONFIG_FILE}"
fi

: "${REFUGE_HOSTNAME:=refugeos}"
: "${REFUGE_USERNAME:=refuge}"
: "${REFUGE_PASSWORD:=refuge}"
: "${REFUGE_ROOT_PASSWORD:=${REFUGE_PASSWORD}}"
: "${REFUGE_TIMEZONE:=$(timedatectl show -p Timezone --value 2>/dev/null || echo UTC)}"
: "${REFUGE_LOCALE:=en_US}"
: "${REFUGE_KEYMAP:=us}"
: "${REFUGE_PARALLEL_DOWNLOADS:=1}"
: "${REFUGE_DISABLE_DOWNLOAD_TIMEOUT:=1}"
: "${REFUGE_PREFETCH_ALL_PACKAGES:=1}"
: "${REFUGE_PREFETCH_RETRIES:=4}"
: "${REFUGE_SET_GEO_MIRROR:=1}"
: "${REFUGE_MIRROR_URL:=https://geo.mirror.pkgbuild.com/\$repo/os/\$arch}"
: "${REFUGE_AUTOLOGIN:=1}"
: "${REFUGE_ENABLE_REFLECTOR_TIMER:=1}"
: "${REFUGE_ENABLE_MULTILIB:=1}"
: "${REFUGE_ENABLE_CHAOTIC:=0}"
: "${REFUGE_ENABLE_AUR_HELPER:=0}"
: "${REFUGE_VENDOR_DRIVERS:=0}"
: "${REFUGE_UI:=1}"
: "${REFUGE_TARGET_DISK:=}"
: "${REFUGE_BOOTLOADER:=auto}"
: "${REFUGE_FILESYSTEM:=auto}"
: "${REFUGE_CONFIRM_SECONDS:=8}"
: "${REFUGE_FORCE_YES:=0}"

log()  { printf '\n==> %s\n' "$*"; }
warn() { printf '\n[warn] %s\n' "$*" >&2; }
die()  { printf '\n[error] %s\n' "$*" >&2; exit 1; }

setup_logging() {
  local dir
  dir="$(dirname -- "${LOG_FILE}")"
  mkdir -p "${dir}" 2>/dev/null || true
  exec > >(tee -a "${LOG_FILE}") 2>&1
}


require_root() {
  if [[ ${EUID} -ne 0 ]]; then
    exec sudo -E bash "$0" "$@"
  fi
}

command_exists() {
  command -v "$1" >/dev/null 2>&1
}

require_cmds() {
  local missing=0 cmd
  for cmd in \
    archinstall arch-chroot pacman pacman-key lsblk findmnt parted partprobe wipefs \
    mkfs.ext4 mkfs.fat rsync python genfstab chpasswd useradd mount umount script; do
    if ! command_exists "$cmd"; then
      warn "Missing command: $cmd"
      missing=1
    fi
  done
  if ! command_exists mkfs.btrfs; then
    warn "Missing command: mkfs.btrfs (install btrfs-progs in the live image if you want Btrfs installs)"
  fi
  (( missing == 0 )) || die "Required installer commands are missing from the live system"
}

sync_time() {
  timedatectl set-ntp true >/dev/null 2>&1 || true
  systemctl restart systemd-timesyncd.service >/dev/null 2>&1 || true
  sleep 2
}

ensure_network() {
  if ping -c 1 -W 2 geo.mirror.pkgbuild.com >/dev/null 2>&1; then
    return 0
  fi
  die "Network is not ready. Connect Ethernet or Wi-Fi first, then rerun the installer."
}

write_pacman_conf() {
  local root="$1"
  install -d "${root}/etc/pacman.d"
  cat > "${root}/etc/pacman.conf" <<EOF_PACMAN
[options]
Architecture = auto
CheckSpace
CacheDir = /var/cache/pacman/pkg
ParallelDownloads = ${REFUGE_PARALLEL_DOWNLOADS}
SigLevel = Required DatabaseOptional
LocalFileSigLevel = Optional
EOF_PACMAN

  if [[ "${REFUGE_DISABLE_DOWNLOAD_TIMEOUT}" == "1" ]]; then
    printf '%s\n' 'DisableDownloadTimeout' >> "${root}/etc/pacman.conf"
  fi

  cat >> "${root}/etc/pacman.conf" <<'EOF_REPOS'

[core]
Include = /etc/pacman.d/mirrorlist

[extra]
Include = /etc/pacman.d/mirrorlist
EOF_REPOS

  if [[ "${REFUGE_ENABLE_MULTILIB}" == "1" ]]; then
    cat >> "${root}/etc/pacman.conf" <<'EOF_MULTI'

[multilib]
Include = /etc/pacman.d/mirrorlist
EOF_MULTI
  fi
}


seed_mirrorlist() {
  local root="$1"
  install -d "${root}/etc/pacman.d"
  cat > "${root}/etc/pacman.d/mirrorlist" <<'EOF_MIRRORS'
Server = https://mirrors.kernel.org/archlinux/$repo/os/$arch
Server = https://mirror.fcix.net/archlinux/$repo/os/$arch
Server = https://arch.mirror.constant.com/$repo/os/$arch
Server = https://arch.goober.cloud/$repo/os/$arch
Server = https://mirror.zackmyers.io/archlinux/$repo/os/$arch
Server = https://geo.mirror.pkgbuild.com/$repo/os/$arch
EOF_MIRRORS
}


prepare_live_pacman() {
  log "Preparing live pacman repository configuration"
  if [[ ! -f "${LIVE_PACMAN_CONF_BACKUP}" && -f /etc/pacman.conf ]]; then
    cp -a /etc/pacman.conf "${LIVE_PACMAN_CONF_BACKUP}" || true
  fi
  seed_mirrorlist ""
  write_pacman_conf ""
}

repair_live_keyring() {
  log "Repairing the live pacman keyring"
  sync_time
  prepare_live_pacman
  killall gpg-agent >/dev/null 2>&1 || true
  rm -rf /etc/pacman.d/gnupg
  install -d -m 700 /etc/pacman.d/gnupg
  pacman-key --init
  pacman-key --populate archlinux
  pacman-key --updatedb || true
  pacman -Syy --noconfirm archlinux-keyring
}

set_geo_mirror() {
  if [[ "${REFUGE_SET_GEO_MIRROR}" == "1" ]]; then
    log "Using Arch geo mirror"
    seed_mirrorlist ""
    pacman -Syy --noconfirm
  fi
}

resolve_package_source() {
  local candidate
  for candidate in     "${PACKAGE_FILE}"     "${PACKAGE_FILE_DEFAULT}"     "/usr/share/refugeos/install/refugeos-packages.txt"; do
    [[ -n "$candidate" && -f "$candidate" ]] || continue
    PACKAGE_FILE="$candidate"
    PACKAGE_SOURCE="manifest"
    return 0
  done
  PACKAGE_FILE=""
  PACKAGE_SOURCE="live-system"
  return 1
}

boot_media_parent_disk() {
  local src parent
  for src in \
    "$(findmnt -nro SOURCE /run/archiso/bootmnt 2>/dev/null || true)" \
    "$(findmnt -nro SOURCE /run/archiso/copytoram 2>/dev/null || true)" \
    "$(findmnt -nro SOURCE / 2>/dev/null || true)"
  do
    [[ -n "$src" ]] || continue
    if [[ -b "$src" ]]; then
      parent="$(lsblk -ndo PKNAME "$src" 2>/dev/null || true)"
      if [[ -n "$parent" ]]; then
        printf '/dev/%s\n' "$parent"
        return 0
      fi
      printf '%s\n' "$src"
      return 0
    fi
  done
  return 1
}

list_candidate_disks() {
  local boot_disk="$1"
  lsblk -bnpo NAME,SIZE,TYPE,RM,RO,TRAN,MODEL | \
  awk -v boot="${boot_disk}" '
    $3=="disk" && $5==0 {
      if ($1 == boot) next;
      if ($1 ~ /\/dev\/(zram|loop|ram)/) next;
      if ($4 == 0) {
        model="";
        for(i=7;i<=NF;i++){ model=(model ? model " " : "") $i }
        print $1 "|" $2 "|" $6 "|" model;
      }
    }
  '
}

list_fallback_disks() {
  local boot_disk="$1"
  lsblk -bnpo NAME,SIZE,TYPE,RM,RO,TRAN,MODEL | \
  awk -v boot="${boot_disk}" '
    $3=="disk" && $5==0 {
      if ($1 == boot) next;
      if ($1 ~ /\/dev\/(zram|loop|ram)/) next;
      model="";
      for(i=7;i<=NF;i++){ model=(model ? model " " : "") $i }
      print $1 "|" $2 "|" $6 "|" model;
    }
  '
}

human_size() {
  local bytes="$1"
  numfmt --to=iec-i --suffix=B --format='%.1f' "$bytes" 2>/dev/null || echo "$bytes"
}

prompt_text() {
  local var_name="$1" prompt="$2" default="$3" value
  read -r -p "$prompt [$default]: " value || true
  value="${value:-$default}"
  printf -v "$var_name" '%s' "$value"
}

prompt_password() {
  local var_name="$1" prompt="$2" value
  while true; do
    read -r -s -p "$prompt: " value || true
    printf '\n'
    [[ -n "$value" ]] && break
    warn "Password cannot be empty"
  done
  printf -v "$var_name" '%s' "$value"
}

prompt_yes_no() {
  local var_name="$1" prompt="$2" default="$3" reply norm
  local shown="Y/n"
  [[ "$default" == "0" ]] && shown="y/N"
  read -r -p "$prompt [$shown]: " reply || true
  reply="${reply:-}"
  case "${reply,,}" in
    y|yes) norm="1" ;;
    n|no) norm="0" ;;
    "") norm="$default" ;;
    *) norm="$default" ;;
  esac
  printf -v "$var_name" '%s' "$norm"
}

select_from_menu() {
  local var_name="$1" prompt="$2"
  shift 2
  local -a opts=("$@")
  local idx choice
  printf '\n%s\n' "$prompt"
  for idx in "${!opts[@]}"; do
    printf '  %d) %s\n' "$((idx+1))" "${opts[$idx]}"
  done
  while true; do
    read -r -p "Choose 1-${#opts[@]}: " choice || true
    if [[ "$choice" =~ ^[0-9]+$ ]] && (( choice >= 1 && choice <= ${#opts[@]} )); then
      printf -v "$var_name" '%s' "${opts[$((choice-1))]}"
      return 0
    fi
  done
}

ui_collect_settings() {
  local boot_disk disk_entries chosen fs_choice model trans size
  [[ "${REFUGE_UI}" == "1" ]] || return 0
  [[ -n "${REFUGE_TARGET_DISK}" ]] && return 0

  boot_disk="$(boot_media_parent_disk || true)"
  mapfile -t disk_entries < <(list_candidate_disks "$boot_disk" | sort -t'|' -k2,2nr)
  if (( ${#disk_entries[@]} == 0 )); then
    mapfile -t disk_entries < <(list_fallback_disks "$boot_disk" | sort -t'|' -k2,2nr)
  fi
  (( ${#disk_entries[@]} > 0 )) || die "No install disks found"

  local -a menu=()
  local entry disk rawsize transport
  for entry in "${disk_entries[@]}"; do
    IFS='|' read -r disk rawsize transport model <<<"$entry"
    size="$(human_size "$rawsize")"
    menu+=("$disk (${size}, ${transport:-unknown}${model:+, $model})")
  done
  select_from_menu chosen "Select the disk to erase and install RefugeOS to:" "${menu[@]}"
  REFUGE_TARGET_DISK="${chosen%% *}"

  select_from_menu fs_choice "Select the root filesystem:" \
    "ext4 (recommended default: simple and fast)" \
    "btrfs (snapshots/compression oriented)"
  case "$fs_choice" in
    ext4*) REFUGE_FILESYSTEM="ext4" ;;
    btrfs*) REFUGE_FILESYSTEM="btrfs" ;;
  esac

  prompt_text REFUGE_HOSTNAME "Hostname" "${REFUGE_HOSTNAME}"
  prompt_text REFUGE_USERNAME "Username" "${REFUGE_USERNAME}"
  prompt_password REFUGE_PASSWORD "User password"
  prompt_yes_no SAME_ROOT "Use the same password for root" 1
  if [[ "${SAME_ROOT}" == "1" ]]; then
    REFUGE_ROOT_PASSWORD="${REFUGE_PASSWORD}"
  else
    prompt_password REFUGE_ROOT_PASSWORD "Root password"
  fi

  prompt_yes_no REFUGE_AUTOLOGIN "Enable tty1 autologin like the live USB" "${REFUGE_AUTOLOGIN}"
  prompt_yes_no REFUGE_ENABLE_MULTILIB "Enable multilib repository" "${REFUGE_ENABLE_MULTILIB}"
  prompt_yes_no REFUGE_ENABLE_CHAOTIC "Enable Chaotic-AUR after install (third-party repo)" "${REFUGE_ENABLE_CHAOTIC}"
  if [[ "${REFUGE_ENABLE_CHAOTIC}" == "1" ]]; then
    prompt_yes_no REFUGE_ENABLE_AUR_HELPER "Install paru AUR helper from Chaotic-AUR" "${REFUGE_ENABLE_AUR_HELPER}"
  fi
  prompt_yes_no REFUGE_VENDOR_DRIVERS "Install detected optional vendor drivers (NVIDIA/Broadcom)" "${REFUGE_VENDOR_DRIVERS}"
}

select_target_disk() {
  local boot_disk candidates fallback

  if [[ -n "${REFUGE_TARGET_DISK}" ]]; then
    [[ -b "${REFUGE_TARGET_DISK}" ]] || die "REFUGE_TARGET_DISK does not exist: ${REFUGE_TARGET_DISK}"
    TARGET_DISK="${REFUGE_TARGET_DISK}"
    return 0
  fi

  boot_disk="$(boot_media_parent_disk || true)"
  log "Boot media disk: ${boot_disk:-unknown}"

  mapfile -t candidates < <(list_candidate_disks "$boot_disk" | sort -t'|' -k2,2nr)
  if (( ${#candidates[@]} == 1 )); then
    TARGET_DISK="${candidates[0]%%|*}"
    return 0
  fi
  if (( ${#candidates[@]} > 1 )); then
    printf '\nDetected multiple possible install disks:\n'
    printf '  %s\n' "${candidates[@]}"
    die "Refusing to guess. Set REFUGE_TARGET_DISK=/dev/yourdisk or run with REFUGE_UI=1 and choose interactively."
  fi

  mapfile -t fallback < <(list_fallback_disks "$boot_disk" | sort -t'|' -k2,2nr)
  if (( ${#fallback[@]} == 1 )); then
    TARGET_DISK="${fallback[0]%%|*}"
    return 0
  fi
  if (( ${#fallback[@]} > 1 )); then
    printf '\nDetected multiple removable/external install disks:\n'
    printf '  %s\n' "${fallback[@]}"
    die "Refusing to guess. Set REFUGE_TARGET_DISK=/dev/yourdisk or run with REFUGE_UI=1 and choose interactively."
  fi

  die "No suitable target disk detected"
}

partition_path() {
  local disk="$1" idx="$2"
  if [[ "$disk" =~ [0-9]$ ]]; then
    printf '%sp%s\n' "$disk" "$idx"
  else
    printf '%s%s\n' "$disk" "$idx"
  fi
}

select_bootloader() {
  if [[ -d /sys/firmware/efi ]]; then
    BOOT_MODE="uefi"
    if [[ "${REFUGE_BOOTLOADER}" == "auto" ]]; then
      BOOTLOADER="Systemd-boot"
    else
      BOOTLOADER="${REFUGE_BOOTLOADER}"
    fi
  else
    BOOT_MODE="bios"
    if [[ "${REFUGE_BOOTLOADER}" == "auto" ]]; then
      BOOTLOADER="grub"
    else
      BOOTLOADER="${REFUGE_BOOTLOADER}"
    fi
  fi
}

select_filesystem() {
  local rota
  case "${REFUGE_FILESYSTEM,,}" in
    btrfs|ext4)
      FILESYSTEM="${REFUGE_FILESYSTEM,,}"
      ;;
    auto|"")
      # Safe default for broad compatibility and predictable behavior.
      FILESYSTEM="ext4"
      ;;
    *)
      die "Unsupported filesystem choice: ${REFUGE_FILESYSTEM}"
      ;;
  esac

  rota="$(lsblk -dnro ROTA "${TARGET_DISK}" 2>/dev/null || echo 1)"
  if [[ "${FILESYSTEM}" == "btrfs" ]]; then
    BTRFS_MOUNT_OPTS="compress=zstd:1,noatime,space_cache=v2"
    [[ "$rota" == "0" ]] && BTRFS_MOUNT_OPTS+=" ,ssd"
    BTRFS_MOUNT_OPTS="${BTRFS_MOUNT_OPTS// /}"
  fi
}

unmount_target_root() {
  if mountpoint -q "${TARGET_ROOT}/boot"; then
    umount -R "${TARGET_ROOT}/boot" || true
  fi
  if mountpoint -q "${TARGET_ROOT}/home"; then
    umount -R "${TARGET_ROOT}/home" || true
  fi
  if mountpoint -q "${TARGET_ROOT}"; then
    umount -R "${TARGET_ROOT}" || true
  fi
}

prepare_target_mounts() {
  log "Preparing target disk ${TARGET_DISK} with ${FILESYSTEM}"
  unmount_target_root
  swapoff -a >/dev/null 2>&1 || true
  mkdir -p "${TARGET_ROOT}"

  wipefs -af "${TARGET_DISK}"
  partprobe "${TARGET_DISK}" >/dev/null 2>&1 || true
  udevadm settle >/dev/null 2>&1 || true

  if [[ "${BOOT_MODE}" == "uefi" ]]; then
    parted -s "${TARGET_DISK}" mklabel gpt
    parted -s "${TARGET_DISK}" mkpart ESP fat32 1MiB 1025MiB
    parted -s "${TARGET_DISK}" set 1 esp on
    parted -s "${TARGET_DISK}" set 1 boot on
    parted -s "${TARGET_DISK}" mkpart primary 1025MiB 100%

    EFI_PART="$(partition_path "${TARGET_DISK}" 1)"
    ROOT_PART="$(partition_path "${TARGET_DISK}" 2)"

    mkfs.fat -F32 "${EFI_PART}"
  else
    parted -s "${TARGET_DISK}" mklabel gpt
    parted -s "${TARGET_DISK}" mkpart BIOSBOOT 1MiB 3MiB
    parted -s "${TARGET_DISK}" set 1 bios_grub on
    parted -s "${TARGET_DISK}" mkpart primary 3MiB 100%

    ROOT_PART="$(partition_path "${TARGET_DISK}" 2)"
  fi

  if [[ "${FILESYSTEM}" == "ext4" ]]; then
    mkfs.ext4 -F "${ROOT_PART}"
    mount "${ROOT_PART}" "${TARGET_ROOT}"
    mkdir -p "${TARGET_ROOT}/home"
  else
    command_exists mkfs.btrfs || die "Btrfs selected but mkfs.btrfs is not available"
    mkfs.btrfs -f "${ROOT_PART}"
    mount "${ROOT_PART}" "${TARGET_ROOT}"
    btrfs subvolume create "${TARGET_ROOT}/@"
    btrfs subvolume create "${TARGET_ROOT}/@home"
    umount "${TARGET_ROOT}"
    mount -o "${BTRFS_MOUNT_OPTS},subvol=@" "${ROOT_PART}" "${TARGET_ROOT}"
    mkdir -p "${TARGET_ROOT}/home"
    mount -o "${BTRFS_MOUNT_OPTS},subvol=@home" "${ROOT_PART}" "${TARGET_ROOT}/home"
  fi

  if [[ "${BOOT_MODE}" == "uefi" ]]; then
    mkdir -p "${TARGET_ROOT}/boot"
    mount "${EFI_PART}" "${TARGET_ROOT}/boot"
  fi
}

build_package_list() {
  local pkg cpu_vendor virt
  local -a selected=()

  if resolve_package_source; then
    log "Using package manifest: ${PACKAGE_FILE}"
    while IFS= read -r pkg; do
      [[ -n "$pkg" && "${pkg:0:1}" != "#" ]] || continue
      if pacman -Si "$pkg" >/dev/null 2>&1 || pacman -Qq "$pkg" >/dev/null 2>&1; then
        selected+=("$pkg")
      fi
    done < "${PACKAGE_FILE}"
  else
    log "No package manifest found; cloning explicit package set from the live RefugeOS session"
    while IFS= read -r pkg; do
      [[ -n "$pkg" ]] || continue
      case "$pkg" in
        archiso|mkinitcpio-archiso) continue ;;
      esac
      selected+=("$pkg")
    done < <(pacman -Qqen | sort -u)
  fi

  selected+=("linux-firmware" "sof-firmware" "reflector" "arch-install-scripts")

  cpu_vendor="$(lscpu 2>/dev/null | awk -F: '/Vendor ID/ {gsub(/^[ 	]+/, "", $2); print $2; exit}')"
  case "$cpu_vendor" in
    GenuineIntel) selected+=("intel-ucode") ;;
    AuthenticAMD) selected+=("amd-ucode") ;;
  esac

  virt="$(systemd-detect-virt 2>/dev/null || true)"
  case "$virt" in
    oracle|virtualbox) selected+=("virtualbox-guest-utils") ;;
    qemu|kvm) selected+=("qemu-guest-agent") ;;
  esac

  if [[ "${REFUGE_VENDOR_DRIVERS}" == "1" ]]; then
    if lspci -nnk 2>/dev/null | grep -Eqi 'NVIDIA'; then
      selected+=("linux-headers" "nvidia-utils" "nvidia-open-dkms")
    fi
    if lspci -nnk 2>/dev/null | grep -Eqi 'Broadcom.*(Network|Wireless|802\.11)'; then
      selected+=("broadcom-wl")
    fi
  fi

  printf '%s\n' "${selected[@]}" | awk '!seen[$0]++' > "${PKG_LIST_FILE}"
}

bootstrap_package_list() {
  local cpu_vendor
  printf '%s\n' archlinux-keyring base sudo linux-firmware linux
  cpu_vendor="$(lscpu 2>/dev/null | awk -F: '/Vendor ID/ {gsub(/^[ \t]+/, "", $2); print $2; exit}')"
  case "$cpu_vendor" in
    GenuineIntel) printf '%s\n' intel-ucode ;;
    AuthenticAMD) printf '%s\n' amd-ucode ;;
  esac
}


ensure_target_cache_dir() {
  install -d "${TARGET_ROOT}/var/cache/pacman/pkg"
  chmod 755 "${TARGET_ROOT}/var/cache/pacman" "${TARGET_ROOT}/var/cache/pacman/pkg" 2>/dev/null || true
}

prefetch_with_retries() {
  local label="$1"
  local cache_dir="$2"
  shift 2
  local attempt=1
  local -a pkgs=("$@")
  (( ${#pkgs[@]} > 0 )) || return 0
  install -d "${cache_dir}"
  while (( attempt <= REFUGE_PREFETCH_RETRIES )); do
    log "Prefetching ${label} packages into ${cache_dir} (attempt ${attempt}/${REFUGE_PREFETCH_RETRIES})"
    pacman -Syy --noconfirm || true
    if pacman -Sw --cachedir "${cache_dir}" --noconfirm --needed "${pkgs[@]}"; then
      return 0
    fi
    warn "Prefetch attempt ${attempt} for ${label} packages failed"
    find "${cache_dir}" -maxdepth 1 -type f \( -name '*.part' -o -name '*.part.sig' \) -delete 2>/dev/null || true
    sleep 5
    attempt=$((attempt+1))
  done
  die "Could not prefetch ${label} packages. Try a faster connection or edit /etc/pacman.d/mirrorlist."
}

prefetch_packages() {
  local cache_dir="${TARGET_ROOT}/var/cache/pacman/pkg"
  local -a bootstrap_pkgs=() all_pkgs=()
  ensure_target_cache_dir
  mapfile -t bootstrap_pkgs < <(bootstrap_package_list | awk '!seen[$0]++')
  prefetch_with_retries "bootstrap" "${cache_dir}" "${bootstrap_pkgs[@]}"

  if [[ "${REFUGE_PREFETCH_ALL_PACKAGES}" == "1" ]]; then
    mapfile -t all_pkgs < <(awk '!seen[$0]++' "${PKG_LIST_FILE}")
    prefetch_with_retries "RefugeOS payload" "${cache_dir}" "${all_pkgs[@]}"
  fi
}

copy_host_cache_to_target() {
  log "Ensuring cached packages are available inside the target system"
  ensure_target_cache_dir
  rsync -a --ignore-existing /var/cache/pacman/pkg/ "${TARGET_ROOT}/var/cache/pacman/pkg/" || true
}

write_archinstall_config() {
  log "Writing unattended archinstall configuration"
  python - "$ARCH_CFG" "$BOOTLOADER" "$REFUGE_HOSTNAME" "$REFUGE_KEYMAP" "$REFUGE_LOCALE" "$REFUGE_TIMEZONE" "$REFUGE_PARALLEL_DOWNLOADS" "$PKG_LIST_FILE" <<'PY'
import json, sys
out, bootloader, hostname, keymap, locale, timezone, parallel, pkg_file = sys.argv[1:9]
with open(pkg_file, 'r', encoding='utf-8') as f:
    packages = [line.strip() for line in f if line.strip()]
config = {
    "archinstall-language": "English",
    "disk_config": {
        "config_type": "pre_mounted_config",
        "mountpoint": "/mnt"
    },
    "audio_config": {"audio": "pipewire"},
    "bootloader_config": {
        "bootloader": bootloader,
        "uki": False,
        "removable": False,
    },
    "hostname": hostname,
    "kernels": ["linux"],
    "locale_config": {
        "kb_layout": keymap,
        "sys_enc": "UTF-8",
        "sys_lang": locale,
    },
    "ntp": True,
    "offline": False,
    "no_pkg_lookups": False,
    "packages": packages,
    "parallel downloads": int(parallel),
    "script": "guided",
    "silent": True,
    "timezone": timezone,
}
with open(out, 'w', encoding='utf-8') as fh:
    json.dump(config, fh, indent=2)
PY

  python - "$ARCH_CREDS" "$REFUGE_ROOT_PASSWORD" <<'PY'
import json, sys
out, root_pw = sys.argv[1:3]
with open(out, 'w', encoding='utf-8') as fh:
    json.dump({"root_enc_password": root_pw}, fh, indent=2)
PY
}

run_archinstall() {
  log "Running archinstall unattended"
  local cmd
  export TERM="${TERM:-xterm-256color}"
  printf -v cmd '%q ' archinstall --silent --config "${ARCH_CFG}" --creds "${ARCH_CREDS}" --skip-wkd
  # Run archinstall inside a pseudo-terminal so its curses/TUI code does not crash
  # if the wrapper is logging through pipes. --silent tells archinstall not to ask TUI questions.
  script -qefc "$cmd" /dev/null
}

find_target_root() {
  local p
  for p in "${TARGET_ROOT}" /mnt /mnt/*; do
    [[ -d "$p" ]] || continue
    [[ -f "$p/etc/os-release" ]] || continue
    if grep -q '^ID=arch' "$p/etc/os-release" 2>/dev/null; then
      printf '%s\n' "$p"
      return 0
    fi
  done
  return 1
}

verify_install_root() {
  if [[ ! -f "${TARGET_ROOT}/etc/os-release" ]]; then
    TARGET_ROOT="$(find_target_root || true)"
  fi
  [[ -n "${TARGET_ROOT}" && -f "${TARGET_ROOT}/etc/os-release" ]] || die "Installed system was not found under a known mountpoint"
  grep -q '^ID=arch' "${TARGET_ROOT}/etc/os-release" || die "Target root does not look like Arch Linux"
}

write_target_fstab() {
  log "Writing target fstab"
  genfstab -U "${TARGET_ROOT}" > "${TARGET_ROOT}/etc/fstab"
}

prepare_target_pacman() {
  log "Preparing pacman inside the installed system"
  seed_mirrorlist "${TARGET_ROOT}"
  write_pacman_conf "${TARGET_ROOT}"
  arch-chroot "${TARGET_ROOT}" bash -lc '
    rm -rf /etc/pacman.d/gnupg
    install -d -m 700 /etc/pacman.d/gnupg
    pacman-key --init
    pacman-key --populate archlinux
    pacman-key --updatedb || true
    pacman -Syy --noconfirm archlinux-keyring
  '
}

enable_target_chaotic() {
  [[ "${REFUGE_ENABLE_CHAOTIC}" == "1" ]] || return 0
  log "Enabling Chaotic-AUR inside the installed system"

  if [[ "${REFUGE_ENABLE_MULTILIB}" != "1" ]]; then
    warn "Chaotic-AUR is normally used with multilib enabled. Enabling multilib now."
    REFUGE_ENABLE_MULTILIB="1"
    write_pacman_conf "${TARGET_ROOT}"
  fi

  arch-chroot "${TARGET_ROOT}" bash -lc '
    pacman-key --recv-key 3056513887B78AEB --keyserver keyserver.ubuntu.com
    pacman-key --lsign-key 3056513887B78AEB
    pacman -U --noconfirm \
      https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-keyring.pkg.tar.zst \
      https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-mirrorlist.pkg.tar.zst
  '

  if ! grep -q '^\[chaotic-aur\]$' "${TARGET_ROOT}/etc/pacman.conf"; then
    cat >> "${TARGET_ROOT}/etc/pacman.conf" <<'EOF_CHAOTIC'

[chaotic-aur]
Include = /etc/pacman.d/chaotic-mirrorlist
EOF_CHAOTIC
  fi

  arch-chroot "${TARGET_ROOT}" pacman -Syy --noconfirm
}

install_target_aur_helper() {
  [[ "${REFUGE_ENABLE_CHAOTIC}" == "1" && "${REFUGE_ENABLE_AUR_HELPER}" == "1" ]] || return 0
  log "Installing paru inside the installed system"
  arch-chroot "${TARGET_ROOT}" pacman -S --needed --noconfirm paru ||     warn "paru could not be installed automatically"
}

install_target_packages_again() {
  log "Ensuring the RefugeOS package set is present inside the installed system"
  mapfile -t pkgs < "${PKG_LIST_FILE}"
  if (( ${#pkgs[@]} > 0 )); then
    arch-chroot "${TARGET_ROOT}" pacman -S --needed --noconfirm "${pkgs[@]}"
  fi
}

create_target_user() {
  log "Creating or updating the installed user"
  if ! arch-chroot "${TARGET_ROOT}" id -u "${REFUGE_USERNAME}" >/dev/null 2>&1; then
    arch-chroot "${TARGET_ROOT}" useradd -m -G wheel -s /bin/bash "${REFUGE_USERNAME}"
  fi

  printf '%s:%s\n' root "${REFUGE_ROOT_PASSWORD}" | arch-chroot "${TARGET_ROOT}" chpasswd
  printf '%s:%s\n' "${REFUGE_USERNAME}" "${REFUGE_PASSWORD}" | arch-chroot "${TARGET_ROOT}" chpasswd

  install -d "${TARGET_ROOT}/etc/sudoers.d"
  printf '%%wheel ALL=(ALL:ALL) ALL\n' > "${TARGET_ROOT}/etc/sudoers.d/10-wheel"
  chmod 440 "${TARGET_ROOT}/etc/sudoers.d/10-wheel"
}

copy_live_custom_files() {
  log "Copying RefugeOS custom files into the installed system"

  if [[ -d /etc/skel ]]; then
    install -d "${TARGET_ROOT}/etc/skel"
    cp -a /etc/skel/. "${TARGET_ROOT}/etc/skel/"
  fi

  if [[ -d "${TARGET_ROOT}/home/${REFUGE_USERNAME}" ]]; then
    cp -a /etc/skel/. "${TARGET_ROOT}/home/${REFUGE_USERNAME}/" || true
    arch-chroot "${TARGET_ROOT}" chown -R "${REFUGE_USERNAME}:${REFUGE_USERNAME}" "/home/${REFUGE_USERNAME}"
  fi

  if [[ -d /usr/share/refugeos ]]; then
    install -d "${TARGET_ROOT}/usr/share/refugeos"
    rsync -a /usr/share/refugeos/ "${TARGET_ROOT}/usr/share/refugeos/"
  fi

  shopt -s nullglob
  local f
  for f in /usr/local/bin/refuge* /usr/local/bin/install-refugeos*; do
    [[ -e "$f" ]] || continue
    install -Dm755 "$f" "${TARGET_ROOT}$f"
  done
  for f in /usr/share/applications/refuge*.desktop /usr/share/pixmaps/refuge* /usr/share/backgrounds/refuge*; do
    [[ -e "$f" ]] || continue
    install -d "${TARGET_ROOT}$(dirname "$f")"
    cp -a "$f" "${TARGET_ROOT}$f"
  done
  shopt -u nullglob

  if [[ -f /etc/systemd/zram-generator.conf ]]; then
    install -Dm644 /etc/systemd/zram-generator.conf "${TARGET_ROOT}/etc/systemd/zram-generator.conf"
  fi

  install -d "${TARGET_ROOT}/usr/share/refugeos/install"
  if [[ -n "${PACKAGE_FILE}" && -f "${PACKAGE_FILE}" ]]; then
    cp -a "${PACKAGE_FILE}" "${TARGET_ROOT}/usr/share/refugeos/install/refugeos-packages.txt"
  else
    cp -a "${PKG_LIST_FILE}" "${TARGET_ROOT}/usr/share/refugeos/install/refugeos-packages.txt"
  fi
  cp -a "${ARCH_CFG}" "${TARGET_ROOT}/usr/share/refugeos/install/archinstall-config.json"
}

configure_target_services() {
  log "Enabling core services inside the installed system"
  local -a services=(
    NetworkManager.service
    systemd-timesyncd.service
    earlyoom.service
    archlinux-keyring-wkd-sync.timer
  )

  if arch-chroot "${TARGET_ROOT}" pacman -Qq reflector >/dev/null 2>&1 && [[ "${REFUGE_ENABLE_REFLECTOR_TIMER}" == "1" ]]; then
    services+=(reflector.timer)
  fi

  if arch-chroot "${TARGET_ROOT}" pacman -Qq qemu-guest-agent >/dev/null 2>&1; then
    services+=(qemu-guest-agent.service)
  fi
  if arch-chroot "${TARGET_ROOT}" pacman -Qq virtualbox-guest-utils >/dev/null 2>&1; then
    services+=(vboxservice.service)
  fi

  arch-chroot "${TARGET_ROOT}" systemctl enable "${services[@]}" || true

  if [[ "${REFUGE_AUTOLOGIN}" == "1" ]]; then
    install -d "${TARGET_ROOT}/etc/systemd/system/getty@tty1.service.d"
    cat > "${TARGET_ROOT}/etc/systemd/system/getty@tty1.service.d/autologin.conf" <<EOC
[Service]
ExecStart=
ExecStart=-/usr/bin/agetty --autologin ${REFUGE_USERNAME} --noclear %I \$TERM
EOC
  fi
}

write_finish_notes() {
  local notes="${TARGET_ROOT}/root/REFUGE-POSTINSTALL.txt"
  cat > "${notes}" <<EOF_NOTES
RefugeOS automatic install finished.

Hostname:    ${REFUGE_HOSTNAME}
User:        ${REFUGE_USERNAME}
Disk:        ${TARGET_DISK}
Boot:        ${BOOT_MODE} (${BOOTLOADER})
Filesystem:  ${FILESYSTEM}
Multilib:    ${REFUGE_ENABLE_MULTILIB}
Chaotic-AUR: ${REFUGE_ENABLE_CHAOTIC}

After first boot:
  1) Log in as ${REFUGE_USERNAME}
  2) Run: sudo refuge-refresh-keys
  3) Run: sudo pacman -Syu
  4) Change both passwords immediately if this machine will stay online

Install log from the live session:
  ${LOG_FILE}
EOF_NOTES
}

show_plan() {
  printf '\nRefugeOS automatic installer plan\n'
  printf '  Target disk:   %s\n' "${TARGET_DISK}"
  printf '  Boot mode:     %s\n' "${BOOT_MODE}"
  printf '  Bootloader:    %s\n' "${BOOTLOADER}"
  printf '  Filesystem:    %s\n' "${FILESYSTEM}"
  printf '  Hostname:      %s\n' "${REFUGE_HOSTNAME}"
  printf '  Username:      %s\n' "${REFUGE_USERNAME}"
  printf '  Autologin:     %s\n' "${REFUGE_AUTOLOGIN}"
  printf '  Multilib:      %s\n' "${REFUGE_ENABLE_MULTILIB}"
  printf '  Chaotic-AUR:   %s\n' "${REFUGE_ENABLE_CHAOTIC}"
  printf '  Vendor drvrs:  %s\n' "${REFUGE_VENDOR_DRIVERS}"
  if [[ -n "${PACKAGE_FILE}" ]]; then
    printf '  Package file:  %s\n' "${PACKAGE_FILE}"
  else
    printf '  Package file:  %s\n' "(auto from live session)"
  fi

  if [[ "${REFUGE_FORCE_YES}" == "1" ]]; then
    printf '\nForce-yes enabled; continuing without countdown.\n'
    return 0
  fi

  printf '\nThis will erase the target disk in %s seconds. Press Ctrl+C now to stop.\n' "${REFUGE_CONFIRM_SECONDS}"
  sleep "${REFUGE_CONFIRM_SECONDS}"
  local confirm
  read -r -p "Type ERASE to continue: " confirm || true
  [[ "$confirm" == "ERASE" ]] || die "Install aborted by user"
}

main() {
  require_root "$@"
  setup_logging
  require_cmds
  ensure_network
  ui_collect_settings
  select_target_disk
  select_bootloader
  select_filesystem
  show_plan
  repair_live_keyring
  set_geo_mirror
  build_package_list
  prepare_target_mounts
  prefetch_packages
  write_archinstall_config
  run_archinstall
  verify_install_root
  copy_host_cache_to_target
  write_target_fstab
  prepare_target_pacman
  enable_target_chaotic
  install_target_packages_again
  install_target_aur_helper
  create_target_user
  copy_live_custom_files
  configure_target_services
  write_finish_notes

  log "RefugeOS automatic installation completed"
  printf 'Installed system root: %s\n' "${TARGET_ROOT}"
  printf 'Post-install notes:    %s\n' "${TARGET_ROOT}/root/REFUGE-POSTINSTALL.txt"
  printf 'You can reboot now.\n'
}

main "$@"

#!/usr/bin/env bash
set -euo pipefail

say()  { printf '%s
' "$*"; }
warn() { printf 'Warning: %s
' "$*" >&2; }
die()  { printf 'Error: %s
' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }


mkarchiso_source_path() {
  command -v mkarchiso 2>/dev/null || true
}

mkarchiso_hardcodes_enquot() {
  local mk
  mk="$(mkarchiso_source_path)"
  [[ -n "$mk" && -r "$mk" ]] || return 1
  grep -Fq -- '--locales="en@quot"' "$mk"
}

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

BASE_PROFILE="${BASE_PROFILE:-baseline}"
WORKROOT="${WORKROOT:-$SCRIPT_DIR/.build}"
OUTDIR="${OUTDIR:-$SCRIPT_DIR/out}"
PROFILE_SRC="/usr/share/archiso/configs/${BASE_PROFILE}"
PROJECT_NAME="${PROJECT_NAME:-refugeos-arch}"
ARCH_MIRROR="${ARCH_MIRROR:-https://geo.mirror.pkgbuild.com/\$repo/os/\$arch}"
LOGFILE="${LOGFILE:-$SCRIPT_DIR/build-$(date +%Y%m%d-%H%M%S).log}"
BUILD_GPGDIR="${BUILD_GPGDIR:-$WORKROOT/pacman-gnupg}"
BUILD_CACHEDIR="${BUILD_CACHEDIR:-$WORKROOT/pacman-cache}"
PACMAN_SIGLEVEL="${PACMAN_SIGLEVEL:-Required DatabaseOptional PackageTrustAll}"
REFUGE_INCLUDE_IA32="${REFUGE_INCLUDE_IA32:-0}"

usage() {
  cat <<'EOF'
Usage:
  ./build.sh doctor
  ./build.sh clean
  ./build.sh <lite|full> [module ...]

Profiles:
  lite | full

Modules:
  security-mini
  security-wireless
  security-heavy
  forensics

Environment:
  BASE_PROFILE=baseline|releng
  ARCH_MIRROR='https://geo.mirror.pkgbuild.com/$repo/os/$arch'
  BUILD_GPGDIR=/absolute/path/to/pacman-gnupg
  BUILD_CACHEDIR=/absolute/path/to/pacman-cache
  PACMAN_SIGLEVEL='Required DatabaseOptional PackageTrustAll'
  REFUGE_INCLUDE_IA32=0|1    # 0 = x86_64 UEFI + BIOS only (default), 1 = also add IA32 UEFI

Examples:
  ./build.sh doctor
  sudo ./build.sh lite
  sudo ./build.sh full security-mini security-wireless
EOF
}

get_os_pretty() {
  if [[ -r /etc/os-release ]]; then
    . /etc/os-release
    printf '%s' "${PRETTY_NAME:-unknown}"
  else
    printf 'unknown'
  fi
}

mount_info() {
  if have findmnt; then
    findmnt -no TARGET,FSTYPE,OPTIONS -T "$PWD" 2>/dev/null || true
  else
    true
  fi
}

host_uses_steamos_repos() {
  grep -Eqs 'steamdeck-packages\.steamos\.cloud|^\[(jupiter|holo|jupiter-rel|holo-rel|core-[0-9]|extra-[0-9])\]' /etc/pacman.conf 2>/dev/null
}

arch_keyring_installed() {
  have pacman && pacman -Q archlinux-keyring >/dev/null 2>&1
}

arch_keyring_files_present() {
  [[ -r /usr/share/pacman/keyrings/archlinux.gpg ]] && [[ -r /usr/share/pacman/keyrings/archlinux-trusted ]]
}

disable_build_cache() {
  rm -rf -- "$BUILD_CACHEDIR"
}

doctor() {
  local mi target fstype opts virt="none" ro_status="n/a"
  mi="$(mount_info)"
  target="$(awk '{print $1}' <<<"$mi" 2>/dev/null || true)"
  fstype="$(awk '{print $2}' <<<"$mi" 2>/dev/null || true)"
  opts="$(cut -d' ' -f3- <<<"$mi" 2>/dev/null || true)"

  if have systemd-detect-virt && systemd-detect-virt -cq; then
    virt="container"
  elif have systemd-detect-virt && systemd-detect-virt -q; then
    virt="vm"
  fi

  if have steamos-readonly; then
    ro_status="$(steamos-readonly status 2>/dev/null || true)"
    ro_status="${ro_status:-unknown}"
  fi

  say "RefugeOS Arch doctor"
  say "--------------------"
  say "Host OS:             $(get_os_pretty)"
  say "Working dir:         $PWD"
  say "Mount target:        ${target:-unknown}"
  say "Filesystem type:     ${fstype:-unknown}"
  say "Mount options:       ${opts:-unknown}"
  say "Virtualization:      ${virt}"
  say "User id:             ${EUID}"
  say "pacman:              $(have pacman && printf yes || printf no)"
  say "mkarchiso:           $(have mkarchiso && printf yes || printf no)"
  say "mkarchiso path:      $(mkarchiso_source_path || true)"
  say "mkarchiso en@quot:   $(mkarchiso_hardcodes_enquot && printf yes || printf no)"
  say "rsync:               $(have rsync && printf yes || printf no)"
  say "base profile:        ${PROFILE_SRC}"
  say "base profile exists: $( [[ -d "$PROFILE_SRC" ]] && printf yes || printf no )"
  say "SteamOS readonly:    ${ro_status}"
  say "SteamOS repos:       $( host_uses_steamos_repos && printf yes || printf no )"
  say "Arch keyring pkg:    $( arch_keyring_installed && printf yes || printf no )"
  say "Arch keyring files:  $( arch_keyring_files_present && printf yes || printf no )"
  say "Build GPGDir:        ${BUILD_GPGDIR}"
  say "Build CacheDir:      ${BUILD_CACHEDIR}"
  say "Arch mirror:         ${ARCH_MIRROR}"
  say "Build SigLevel:      ${PACMAN_SIGLEVEL}"
  say "Include IA32 UEFI:   ${REFUGE_INCLUDE_IA32}"
  say "Free disk (PWD):     $(df -h . | awk 'NR==2{print $4}')"
  say

  if ! have pacman; then
    warn "This host does not look like Arch Linux."
  fi
  if ! have mkarchiso; then
    warn "Install archiso first: sudo pacman -S archiso"
  fi
  if ! have rsync; then
    warn "Install rsync first: sudo pacman -S rsync"
  fi
  if mkarchiso_hardcodes_enquot; then
    warn "Host mkarchiso hardcodes GRUB locale en@quot. build.sh will use a local patched mkarchiso copy for this ISO build only."
  fi
  if [[ ! -d "$PROFILE_SRC" ]]; then
    warn "Official archiso profile not found at ${PROFILE_SRC}"
  fi
  if have steamos-readonly; then
    if steamos-readonly status 2>/dev/null | grep -qi 'enabled\|true\|read-only'; then
      warn "SteamOS readonly mode appears enabled. Building directly on Steam Deck may require temporarily disabling readonly mode."
    fi
  fi
  if host_uses_steamos_repos; then
    warn "Host pacman appears to use SteamOS/Valve repos. build.sh will override the build pacman.conf to use official Arch mirrors."
  fi
  if ! arch_keyring_installed; then
    warn "archlinux-keyring is not installed on the host."
  fi
  if ! arch_keyring_files_present; then
    warn "Arch keyring files are missing from /usr/share/pacman/keyrings. Install archlinux-keyring before building."
  fi
}

check_root_or_reexec() {
  if (( EUID == 0 )); then
    return 0
  fi
  if have sudo; then
    exec sudo --preserve-env=BASE_PROFILE,WORKROOT,OUTDIR,PROJECT_NAME,ARCH_MIRROR,LOGFILE,BUILD_GPGDIR,BUILD_CACHEDIR,PACMAN_SIGLEVEL,REFUGE_INCLUDE_IA32 "$0" "$@"
  fi
  die "Run this script as root or install sudo."
}

validate_profile() {
  case "$1" in
    lite|full) ;;
    *) die "Unsupported profile '$1'. Use lite or full." ;;
  esac
}

validate_module() {
  case "$1" in
    security-mini|security-wireless|security-heavy|forensics) ;;
    *) die "Unsupported module '$1'." ;;
  esac
}

require_tools() {
  have pacman || die "pacman not found. Build this on Arch Linux."
  have pacman-key || die "pacman-key not found. Install pacman first."
  have mkarchiso || die "mkarchiso not found. Install archiso first: sudo pacman -S archiso"
  have rsync || die "rsync not found. Install rsync first: sudo pacman -S rsync"
  [[ -d "$PROFILE_SRC" ]] || die "Official archiso profile not found at ${PROFILE_SRC}"
}

check_space() {
  local avail_mb
  avail_mb="$(df -Pm . | awk 'NR==2 {print $4}')"
  if [[ -n "$avail_mb" && "$avail_mb" -lt 12000 ]]; then
    warn "Less than 12 GB free in the current filesystem. archiso builds can fail when workspace is too small."
  fi
}

combine_package_lists() {
  local output="$1"; shift
  local tmp
  tmp="$(mktemp)"
  cat "$output" > "$tmp"

  local list
  for list in "$@"; do
    [[ -f "$list" ]] || die "Missing package list: $list"
    printf '
# from %s
' "${list##*/}" >> "$tmp"
    cat "$list" >> "$tmp"
    printf '
' >> "$tmp"
  done

  awk '
    /^[[:space:]]*#/ { print; next }
    /^[[:space:]]*$/ { print; next }
    !seen[$0]++ { print }
  ' "$tmp" > "${output}.new"

  mv "${output}.new" "$output"
  rm -f "$tmp"
}

prune_profile_packages() {
  local pkgfile="$1"
  local pkg
  local remove=(
    cloud-init
    hyperv
    open-vm-tools
    qemu-guest-agent
    virtualbox-guest-utils-nox
  )
  for pkg in "${remove[@]}"; do
    sed -i "/^[[:space:]]*${pkg}[[:space:]]*$/d" "$pkgfile"
  done
}

ensure_build_keyring() {
  arch_keyring_files_present || die "Missing /usr/share/pacman/keyrings/archlinux.gpg or archlinux-trusted. Install archlinux-keyring on the host first."

  rm -rf -- "$BUILD_GPGDIR"
  install -d -m 700 "$BUILD_GPGDIR"
  install -d -m 755 "$BUILD_CACHEDIR"

  say "Preparing isolated pacman keyring for the build..."
  pacman-key --gpgdir "$BUILD_GPGDIR" --init >/dev/null 2>&1 || pacman-key --gpgdir "$BUILD_GPGDIR" --init

  # Import the official Arch keyring material directly, then populate/update using pacman-key.
  # This avoids depending on the host's trustdb state and keeps the build isolated.
  if have gpg; then
    gpg --batch --homedir "$BUILD_GPGDIR" --import /usr/share/pacman/keyrings/archlinux.gpg >/dev/null 2>&1 || true
    if [[ -r /usr/share/pacman/keyrings/archlinux-trusted ]]; then
      gpg --batch --homedir "$BUILD_GPGDIR" --import-ownertrust < /usr/share/pacman/keyrings/archlinux-trusted >/dev/null 2>&1 || true
    fi
  fi

  pacman-key --gpgdir "$BUILD_GPGDIR" --populate archlinux >/dev/null 2>&1 || pacman-key --gpgdir "$BUILD_GPGDIR" --populate archlinux
  if [[ -r /usr/share/pacman/keyrings/holo.gpg ]]; then
    pacman-key --gpgdir "$BUILD_GPGDIR" --populate holo >/dev/null 2>&1 || true
  fi
  pacman-key --gpgdir "$BUILD_GPGDIR" --updatedb >/dev/null 2>&1 || true
}
write_clean_pacman_conf() {
  local profile_dir="$1"
  local pacconf="${profile_dir}/pacman.conf"

  install -d -m 755 "$BUILD_CACHEDIR"
  install -d -m 700 "$BUILD_GPGDIR"

  cat > "$pacconf" <<EOF
[options]
Architecture = auto
CheckSpace
SigLevel = ${PACMAN_SIGLEVEL}
LocalFileSigLevel = Optional
ParallelDownloads = 5
CacheDir = ${BUILD_CACHEDIR}
GPGDir = ${BUILD_GPGDIR}

[core]
Server = ${ARCH_MIRROR}

[extra]
Server = ${ARCH_MIRROR}
EOF
}

write_manifest() {
  local flavor="$1"; shift
  local profile_dir="$1"; shift
  local manifest="${profile_dir}/airootfs/usr/share/refugeos/build-manifest.txt"
  mkdir -p "$(dirname "$manifest")"
  {
    echo "RefugeOS Arch build manifest"
    echo "Built: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
    echo "Flavor: $flavor"
    echo "Base profile: $BASE_PROFILE"
    echo "Arch mirror: $ARCH_MIRROR"
    echo "Build GPGDir: $BUILD_GPGDIR"
    echo "Build CacheDir: $BUILD_CACHEDIR"
    echo "Build SigLevel: $PACMAN_SIGLEVEL"
    echo "Include IA32 UEFI: $REFUGE_INCLUDE_IA32"
    if (( $# > 0 )); then
      echo "Modules: $*"
    else
      echo "Modules: none"
    fi
  } > "$manifest"
}


patch_profiledef() {
  local flavor="$1"; shift
  local profile_dir="$1"; shift
  local label_suffix
  label_suffix="$(date +%Y%m%d)"
  cat >> "${profile_dir}/profiledef.sh" <<EOF

# RefugeOS overrides appended by build.sh
iso_name="${PROJECT_NAME}-${flavor}"
iso_label="REFUGE_${flavor^^}_${label_suffix}"
iso_publisher="RefugeOS Project"
iso_application="RefugeOS Arch ${flavor} live system"

# Avoid requiring host-side GRUB IA32 modules by default.
# REFUGE_INCLUDE_IA32=1 re-enables IA32 UEFI output for rare 32-bit UEFI systems.
if [[ "${REFUGE_INCLUDE_IA32:-0}" == "1" ]]; then
  bootmodes=(
    'bios.syslinux.mbr'
    'bios.syslinux.eltorito'
    'uefi-ia32.grub.esp'
    'uefi-x64.grub.esp'
    'uefi-ia32.grub.eltorito'
    'uefi-x64.grub.eltorito'
  )
else
  bootmodes=(
    'bios.syslinux.mbr'
    'bios.syslinux.eltorito'
    'uefi-x64.grub.esp'
    'uefi-x64.grub.eltorito'
  )
fi
EOF
}


prepare_local_mkarchiso() {
  local src dest
  src="$(mkarchiso_source_path)"
  [[ -n "$src" && -r "$src" ]] || die "mkarchiso not found in PATH."

  install -d -m 755 "${WORKROOT}/bin"
  dest="${WORKROOT}/bin/mkarchiso"
  cp -- "$src" "$dest"
  chmod +x "$dest"

  if grep -Fq -- '--locales="en@quot"' "$dest"; then
    sed -i '/--locales="en@quot"/d' "$dest"
  fi

  printf '%s' "$dest"
}

prepare_profile() {
  local flavor="$1"; shift
  local profile_dir="${WORKROOT}/profile-${flavor}"
  rm -rf "$profile_dir"
  mkdir -p "$WORKROOT" "$OUTDIR"
  rsync -a "${PROFILE_SRC}/" "${profile_dir}/"

  [[ -f "${profile_dir}/packages.x86_64" ]] || die "Expected ${profile_dir}/packages.x86_64 in the archiso profile."

  local lists=(
    "${SCRIPT_DIR}/packages/common.list"
    "${SCRIPT_DIR}/packages/${flavor}.list"
  )
  local module
  for module in "$@"; do
    validate_module "$module"
    lists+=( "${SCRIPT_DIR}/modules/${module}.list" )
  done

  combine_package_lists "${profile_dir}/packages.x86_64" "${lists[@]}"
  prune_profile_packages "${profile_dir}/packages.x86_64"
  write_clean_pacman_conf "$profile_dir"

  rsync -a "${SCRIPT_DIR}/overlays/common/" "${profile_dir}/"
  if [[ -d "${SCRIPT_DIR}/overlays/${flavor}" ]]; then
    rsync -a "${SCRIPT_DIR}/overlays/${flavor}/" "${profile_dir}/"
  fi

  write_manifest "$flavor" "$profile_dir" "$@"
  patch_profiledef "$flavor" "$profile_dir"

  [[ -f "${profile_dir}/airootfs/root/customize_airootfs.sh" ]] && chmod +x "${profile_dir}/airootfs/root/customize_airootfs.sh"

  printf '%s' "$profile_dir"
}

build_iso() {
  local flavor="$1"; shift
  ensure_build_keyring
  local mkarchiso_bin
  mkarchiso_bin="$(prepare_local_mkarchiso)"
  local profile_dir
  profile_dir="$(prepare_profile "$flavor" "$@")"

  local work_dir="${WORKROOT}/work-${flavor}"
  rm -rf "$work_dir"
  mkdir -p "$work_dir"

  say "Building ${flavor} image from ${BASE_PROFILE} profile..."
  say "Output directory: ${OUTDIR}"
  say "Workspace:        ${work_dir}"
  say "Arch mirror:      ${ARCH_MIRROR}"
  say "Pacman config:    ${profile_dir}/pacman.conf"
  say "Build GPGDir:     ${BUILD_GPGDIR}"
  say "Build CacheDir:   ${BUILD_CACHEDIR}"
  say "Build SigLevel:   ${PACMAN_SIGLEVEL}"
  if (( $# > 0 )); then
    say "Modules:          $*"
  else
    say "Modules:          none"
  fi
  say "mkarchiso used:    ${mkarchiso_bin}"
  say "Log file:         ${LOGFILE}"
  say

  set -o pipefail
  "$mkarchiso_bin" -C "${profile_dir}/pacman.conf" -v -w "$work_dir" -o "$OUTDIR" "$profile_dir" 2>&1 | tee "$LOGFILE"

  say
  say "Done."
  say "Look in: ${OUTDIR}"
}

main() {
  local cmd="${1:-}"
  case "$cmd" in
    ""|-h|--help|help)
      usage
      ;;
    doctor)
      doctor
      ;;
    clean)
      rm -rf "$WORKROOT" "$OUTDIR"
      say "Removed ${WORKROOT} and ${OUTDIR}"
      ;;
    lite|full)
      local flavor="$1"; shift || true
      validate_profile "$flavor"
      require_tools
      check_space
      check_root_or_reexec "$flavor" "$@"
      build_iso "$flavor" "$@"
      ;;
    *)
      die "Unknown command '$cmd'. Run ./build.sh --help"
      ;;
  esac
}

main "$@"

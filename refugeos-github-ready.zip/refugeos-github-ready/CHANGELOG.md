# Changelog

## 0.1.0

- initial Arch-based RefugeOS starter tree
- lite and full profiles
- offline Bible/library layout
- Firefox-based Refuge Browser launcher
- optional security and forensics modules
- SteamOS / Arch-oriented build flow
- isolated build keyring and cache
- IA32 UEFI disabled by default
- local mkarchiso patch for the `en@quot` GRUB locale issue
- GitHub-ready repository metadata and documentation

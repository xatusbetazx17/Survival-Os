#!/usr/bin/env bash
set -euo pipefail

say()  { printf '%s\n' "$*"; }
die()  { printf 'Error: %s\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

(( EUID == 0 )) || exec sudo "$0" "$@"

have pacman-key || die "pacman-key not found"
[[ -r /usr/share/pacman/keyrings/archlinux.gpg ]] || die "archlinux.gpg not found under /usr/share/pacman/keyrings. Install archlinux-keyring first."

say "Initializing the host pacman keyring..."
pacman-key --init || true

say "Populating Arch Linux keys..."
pacman-key --populate archlinux

if [[ -r /usr/share/pacman/keyrings/holo.gpg ]]; then
  say "Populating SteamOS/Valve keys too..."
  pacman-key --populate holo || true
fi

say "Updating trust database..."
pacman-key --updatedb || true

say
say "Done. You can now rerun the build:"
say "  sudo ./build.sh clean"
say "  sudo ./build.sh full security-mini security-wireless"

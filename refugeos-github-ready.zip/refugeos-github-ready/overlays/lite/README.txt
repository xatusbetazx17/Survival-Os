Lite overlay placeholder.

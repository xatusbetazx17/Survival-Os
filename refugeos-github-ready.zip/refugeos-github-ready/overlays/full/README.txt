Full overlay placeholder.

RefugeLibrary

This folder is the working library for RefugeOS.

Suggested use:
- Bible/               public-domain Bibles, SWORD modules, study material
- Kiwix/               .zim files
- Manuals/             PDFs and practical manuals
- Maps/                offline maps, GPX tracks
- Medical/             first-aid and sanitation references
- Radio/               communication and frequencies notes
- Local/               addresses, contacts, routes, local plans
- Videos/              offline training videos
- Notes/               plain-text notes and checklists
- Backups/             copies of important files
- Personal-Encrypted/  sensitive material you encrypt yourself

# Field checklist

## Core
- water container
- water purification method
- food basics
- layered clothing
- boots
- lighting
- battery bank
- radio
- paper notebook
- printed contact sheet
- maps
- spare USB

## Digital
- browser works
- Wi-Fi works
- Bible works offline
- notes open
- PDF reader works
- backups copied

# Start here

Test these first:

- Wi-Fi
- Browser
- Bible PDF
- Xiphos
- USB file copy
- PDF reading
- Note editing
- Video playback

Then preload the content that matters most to you.

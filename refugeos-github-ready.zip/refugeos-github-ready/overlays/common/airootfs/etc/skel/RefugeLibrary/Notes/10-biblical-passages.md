# Biblical passages to review

These are core passages often associated with wilderness preparation, endurance, and faithful provision:

- Matthew 24
- Revelation 12
- Psalm 91
- Proverbs 6
- Proverbs 21
- Genesis 41
- Acts 2
- Acts 4

Keep both digital and paper copies of the passages most important to you.

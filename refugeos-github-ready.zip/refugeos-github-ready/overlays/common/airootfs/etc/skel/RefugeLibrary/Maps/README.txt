Place offline map files, GPX tracks, and route notes here.
Use Marble and QMapShack from the full profile for larger map workflows.

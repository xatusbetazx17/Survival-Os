RefugeOS quick start

1. Connect to Wi-Fi from the network menu.
2. Open "Refuge Browser" for normal web use.
3. Open the Bible PDF from the desktop or RefugeLibrary/Bible.
4. Launch Xiphos for Bible study modules.
5. Launch Kiwix when you add ZIM files.
6. Keep large offline content on a second USB or SSD.

This image is designed to be practical first:
- boot
- connect
- read
- upload
- copy files
- work offline when needed

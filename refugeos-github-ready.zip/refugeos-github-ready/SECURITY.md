# Security Policy

RefugeOS may ship optional network, audit, and recovery tools.

These tools are intended for:

- lawful defensive testing
- education
- lab work
- recovery and troubleshooting
- personal infrastructure hardening

Do not use this repository or its images to access, disrupt, or attack systems without explicit authorization.

## Reporting a security issue in the build scripts

Open a private report if the issue would let a malicious actor:

- inject files into the generated ISO
- bypass package trust protections
- execute unintended commands during build
- expose secrets stored in build hosts

For non-sensitive issues, open a normal GitHub issue.

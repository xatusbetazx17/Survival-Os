# Library plan

Do not try to shove every possible file into the first ISO.

## Keep the live image focused

Put inside the ISO:
- browser
- Bible reader
- one public-domain Bible PDF
- note editor
- spreadsheet
- PDF reader
- Kiwix app
- essential utilities

Put on a second storage device or a bigger persistent install:
- large Kiwix ZIM files
- offline maps
- radio manuals
- first-aid references
- agriculture PDFs
- personal documents
- offline videos

## Suggested structure

```text
RefugeLibrary/
  Bible/
  Kiwix/
  Manuals/
  Maps/
  Medical/
  Radio/
  Local/
  Videos/
  Notes/
  Backups/
  Personal-Encrypted/
```

# Steam Deck / SteamOS build notes

SteamOS is Arch-based, but it is not the same thing as a normal writable Arch workstation.

## Important reality

By default SteamOS uses a read-only system image.  
That means anything installed with pacman directly onto the base OS may be fragile across updates.

## Safer ways to build

Best:
- separate Arch PC
- Arch VM
- Arch install on external SSD / USB

Acceptable:
- Steam Deck with a carefully prepared writable Arch environment

Least desirable:
- hacking the base SteamOS filesystem every time

## Practical advice

If you build from the Deck itself:

1. verify you have enough free storage
2. make sure the working directory is on writable Linux storage
3. expect rebuilds after some SteamOS updates if you modify the base OS
4. keep the project folder on an external SSD if possible

## Recommended path

Use the Deck mainly as:
- a test target
- a portable reference machine
- a host for your finished USB or SSD image

Use a normal Arch box or VM as:
- the ISO builder

# Field notes for the project

Keep the software side realistic.

## Do first

- make it boot reliably
- make Wi-Fi reliable
- make browser uploads reliable
- make Bible access work offline
- make file copy / USB mounting reliable

## Do second

- preload real content
- tune RAM use
- add security modules
- add offline maps and manuals

## Do last

- theme polish
- branding extras
- huge package collections
- highly specialized tools you may never use

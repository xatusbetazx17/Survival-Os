# Troubleshooting

## VirtualBox boots to a black screen

First question: is it really a full black-screen boot failure?

If you can still see:

- the bottom panel
- the system tray
- the clock
- launcher icons

then the desktop session has probably loaded and the problem is mostly visual.

Try this first:

- click the browser launcher
- open the menu
- open FeatherPad or Terminal
- test keyboard and mouse response

If apps open, the ISO is booting.

## Recommended VirtualBox settings for first boot

- Graphics controller: `VMSVGA`
- Video memory: `128 MB`
- 3D acceleration: `Off`
- RAM: `2048 MB` minimum for `lite`, more for `full`

## If the display is still bad

Try these one at a time:

1. turn **3D acceleration off**
2. increase video memory
3. switch between BIOS and EFI boot in the VM settings
4. if VMSVGA still acts up, try `VBoxSVGA` as a fallback
5. try the `lite` profile
6. test the ISO on a real USB boot

## Build succeeds but ISO does not appear

Check:

```bash
ls -lh out/
```

## Signature / keyring failures

Do a clean rebuild:

```bash
sudo ./build.sh clean
sudo rm -rf ./.build/pacman-gnupg ./.build/pacman-cache
./build.sh doctor
```

## GRUB / locale / IA32 UEFI build failures

Use the latest `build.sh` from this repository. The current script already patches the `en@quot` locale issue and disables IA32 UEFI by default.

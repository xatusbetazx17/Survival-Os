# VirtualBox Notes

RefugeOS can boot in VirtualBox, but a virtual machine is not the final test.

## Recommended VM settings

- Guest type: Linux (64-bit)
- RAM: 2 GB for `lite`, 4 GB or more for `full`
- CPU: 2 cores or more
- Display: `VMSVGA`
- Video memory: `128 MB`
- 3D acceleration: off for first boot
- Storage: use the ISO as optical media

## What counts as success

A successful first boot does not have to look pretty.

If the system reaches:

- the panel
- the clock
- the launchers
- a usable mouse pointer

then the ISO is already booting.

## Better validation path

1. test in VirtualBox
2. test in QEMU if available
3. write to USB
4. boot on a real machine
5. verify Wi-Fi, browser, file access, and shutdown behavior

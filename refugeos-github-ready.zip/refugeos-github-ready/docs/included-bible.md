# Included Bible

The starter kit includes a local PDF copy of the **World English Bible (2020 stable text)** inside the live user's library:

```text
/home/refuge/RefugeLibrary/Bible/World-English-Bible-2020.pdf
```

Reason:
- it is practical
- it is offline
- it gives the image a real complete Bible from day one
- it does not depend on a module downloader

Xiphos and the SWORD library are also installed so you can add SWORD modules later.

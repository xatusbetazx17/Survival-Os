# Applying the package set to an existing Arch install

This is useful when you want the RefugeOS software stack on:

- a normal Arch desktop
- an external SSD with Arch already installed
- a test VM
- a Steam Deck only if you accept SteamOS persistence caveats

## Script

```bash
TARGET_USER=<your-user> sudo ./scripts/apply-to-current-arch.sh lite
TARGET_USER=<your-user> sudo ./scripts/apply-to-current-arch.sh full security-mini
```

## What it does

- installs the selected package manifests with pacman
- installs the Refuge Browser launcher and start page
- installs the library skeleton into the target user's home
- installs desktop launchers
- enables NetworkManager and earlyoom

## What it does not do

- replace your existing desktop session
- build an ISO
- guarantee persistence on SteamOS base updates

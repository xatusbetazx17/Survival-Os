# Persistence strategy

A live ISO is useful, but it is not the whole answer.

## Best model

### Mode 1: emergency live USB
Use when:
- borrowing a computer
- recovering files
- traveling light
- you need the system to boot almost anywhere

### Mode 2: installed persistent USB SSD
Use when:
- you want saved browser state
- you want your notes to persist
- you want Kiwix libraries and maps to stay in place
- you want updates and long-term use

## Recommendation

Build the ISO first.

Then create a second device:

- external SSD
- Arch installed onto that SSD
- same package lists as this project
- same `RefugeLibrary` structure
- encrypted personal partition if needed

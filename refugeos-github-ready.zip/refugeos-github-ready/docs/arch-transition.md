# Why the project moved to Arch

This version pivots the project from Debian live-build to Arch/archiso.

## Why

- Steam Deck / SteamOS users are already living in an Arch-based ecosystem.
- `mkarchiso` is the official Arch-native build path.
- The official archiso profiles are easier to modify than continuing to patch broken Debian host/container/chroot setups.
- Arch package freshness is good for browser, media, and security tooling.

## Honest tradeoff

Arch is **not** the best choice for extremely old 32-bit hardware.  
This project accepts that tradeoff in exchange for:

- easier native builds on Arch
- a cleaner Steam Deck-adjacent workflow
- simpler module expansion later

## Practical meaning

- build host becomes Arch
- output target is x86_64
- baseline live ISO is still only the first step
- truly persistent field use is better on an installed USB SSD

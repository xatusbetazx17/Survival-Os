---
name: Feature request
about: Suggest an improvement for RefugeOS
---

## What do you want added or changed?

## Why does it matter?

## Is this for lite, full, or both?

## Does it increase RAM, storage, or complexity?

## Safer / lighter alternative?

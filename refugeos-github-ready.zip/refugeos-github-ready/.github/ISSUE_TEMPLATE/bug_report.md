---
name: Bug report
about: Report a build or boot problem
---

## What happened

## What you expected

## Host system
- distro:
- kernel:
- virtualization or bare metal:

## Build command used

```bash
paste command here
```

## First relevant error block

```text
paste error here
```

## ISO profile and modules

## Screenshots or photos

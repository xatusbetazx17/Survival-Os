# Contributing

Thanks for wanting to improve RefugeOS.

## Good contributions

- lighter package choices
- hardware compatibility fixes
- VirtualBox / QEMU test notes
- cleaner first-boot experience
- better offline documentation organization
- package manifest cleanup
- build reliability fixes
- low-resource optimizations

## Before opening a PR

1. Run `./build.sh doctor`
2. Test the build you changed
3. Write down what host you used
4. Include the exact command used to build
5. Include the first relevant error block if the build fails

## Commit style

Keep commit messages direct:

- `fix: drop IA32 UEFI by default`
- `docs: add VirtualBox test notes`
- `feat: add offline map placeholders`
- `perf: remove unnecessary packages from lite`

## Scope

RefugeOS favors practical, understandable changes over flashy complexity.

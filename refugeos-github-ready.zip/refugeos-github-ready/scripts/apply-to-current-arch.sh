#!/usr/bin/env bash
set -euo pipefail

say()  { printf '%s\n' "$*"; }
warn() { printf 'Warning: %s\n' "$*" >&2; }
die()  { printf 'Error: %s\n' "$*" >&2; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$SCRIPT_DIR"

usage() {
  cat <<'EOF'
Usage:
  TARGET_USER=<your-user> sudo ./scripts/apply-to-current-arch.sh <lite|full> [module ...]

This installs the RefugeOS package manifests onto the current Arch system and
copies the non-destructive user-facing files (browser launcher, library tree,
desktop launchers, start page).

Examples:
  TARGET_USER=marcelo sudo ./scripts/apply-to-current-arch.sh lite
  TARGET_USER=marcelo sudo ./scripts/apply-to-current-arch.sh full security-mini
EOF
}

validate_profile() {
  case "$1" in
    lite|full) ;;
    *) die "Unsupported profile '$1'. Use lite or full." ;;
  esac
}

validate_module() {
  case "$1" in
    security-mini|security-wireless|security-heavy|forensics) ;;
    *) die "Unsupported module '$1'." ;;
  esac
}

check_root() {
  (( EUID == 0 )) || die "Run this script with sudo."
}

target_user() {
  if [[ -n "${TARGET_USER:-}" ]]; then
    printf '%s' "$TARGET_USER"
    return 0
  fi
  if [[ -n "${SUDO_USER:-}" && "${SUDO_USER:-}" != "root" ]]; then
    printf '%s' "$SUDO_USER"
    return 0
  fi
  awk -F: '$3 >= 1000 && $3 < 65534 {print $1; exit}' /etc/passwd
}

collect_packages() {
  local flavor="$1"; shift
  awk '
    /^[[:space:]]*#/ {next}
    /^[[:space:]]*$/ {next}
    !seen[$0]++ {print $0}
  ' \
    "$SCRIPT_DIR/packages/common.list" \
    "$SCRIPT_DIR/packages/${flavor}.list" \
    "$@"
}

main() {
  [[ "${1:-}" =~ ^(-h|--help|help)$ ]] && usage && exit 0
  local flavor="${1:-}"
  [[ -n "$flavor" ]] || { usage; exit 1; }
  shift || true

  validate_profile "$flavor"
  for m in "$@"; do validate_module "$m"; done

  check_root
  have pacman || die "pacman not found. This script is for Arch-based systems."

  local user
  user="$(target_user)"
  [[ -n "$user" ]] || die "Could not determine TARGET_USER."
  id "$user" >/dev/null 2>&1 || die "User '$user' does not exist."

  local lists=()
  for m in "$@"; do
    lists+=( "$SCRIPT_DIR/modules/${m}.list" )
  done

  say "Installing packages for profile: $flavor"
  if (( $# > 0 )); then
    say "Modules: $*"
  else
    say "Modules: none"
  fi
  say "Target user: $user"
  say

  mapfile -t pkgs < <(collect_packages "$flavor" "${lists[@]}")
  pacman -S --needed "${pkgs[@]}"

  say
  say "Copying system files..."
  rsync -a "$SCRIPT_DIR/overlays/common/airootfs/usr/" /usr/
  install -D -m 0644 "$SCRIPT_DIR/overlays/common/airootfs/etc/systemd/zram-generator.conf" /etc/systemd/zram-generator.conf

  say "Enabling services..."
  systemctl enable NetworkManager.service || true
  systemctl enable earlyoom.service || true

  local home_dir
  home_dir="$(getent passwd "$user" | cut -d: -f6)"
  [[ -d "$home_dir" ]] || die "Home directory for '$user' not found."

  say "Copying user library skeleton..."
  rsync -a --ignore-existing "$SCRIPT_DIR/overlays/common/airootfs/etc/skel/RefugeLibrary/" "$home_dir/RefugeLibrary/"
  mkdir -p "$home_dir/Desktop"
  rsync -a --ignore-existing "$SCRIPT_DIR/overlays/common/airootfs/etc/skel/Desktop/" "$home_dir/Desktop/"
  chown -R "$user":"$user" "$home_dir/RefugeLibrary" "$home_dir/Desktop" || true

  say
  warn "This script does not replace your desktop session or auto-login."
  warn "On SteamOS, pacman-side changes can be wiped by future OS updates."
  say "Done."
}

main "$@"

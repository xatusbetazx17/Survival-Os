#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
awk '
  /^[[:space:]]*#/ {next}
  /^[[:space:]]*$/ {next}
  {print}
' "$SCRIPT_DIR"/packages/*.list "$SCRIPT_DIR"/modules/*.list | sort | uniq -c | sort -k2

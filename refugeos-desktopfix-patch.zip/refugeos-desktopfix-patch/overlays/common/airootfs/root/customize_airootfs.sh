#!/usr/bin/env bash
set -euo pipefail

# locale
if grep -q '^#en_US.UTF-8 UTF-8' /etc/locale.gen 2>/dev/null; then
  sed -i 's/^#en_US.UTF-8 UTF-8/en_US.UTF-8 UTF-8/' /etc/locale.gen
fi
locale-gen || true
echo 'LANG=en_US.UTF-8' > /etc/locale.conf

# create the live user
if ! id refuge >/dev/null 2>&1; then
  useradd -m -G wheel,audio,video,storage,optical -s /bin/bash refuge
fi
passwd -d refuge || true

# passwordless sudo for the live environment
install -d -m 0755 /etc/sudoers.d
cat > /etc/sudoers.d/10-refuge-live <<'EOF'
refuge ALL=(ALL) NOPASSWD: ALL
EOF
chmod 0440 /etc/sudoers.d/10-refuge-live

# autologin on tty1 into the refuge user
install -d -m 0755 /etc/systemd/system/getty@tty1.service.d
cat > /etc/systemd/system/getty@tty1.service.d/autologin.conf <<'EOF'
[Service]
ExecStart=
ExecStart=-/usr/bin/agetty --autologin refuge --noclear %I $TERM
EOF

# enable practical services
systemctl enable NetworkManager.service || true
systemctl enable systemd-timesyncd.service || true
systemctl enable earlyoom.service || true

# make wireshark capture easier if the group exists
if getent group wireshark >/dev/null 2>&1; then
  usermod -aG wireshark refuge || true
fi

# copy the live skeleton explicitly so desktop files and X configs always exist
install -d -m 0755 /home/refuge
cp -a /etc/skel/. /home/refuge/ || true
find /home/refuge/Desktop -maxdepth 1 -type f -name '*.desktop' -exec chmod +x {} \; || true
chmod +x /home/refuge/.xinitrc /home/refuge/.config/openbox/autostart 2>/dev/null || true

# ownership
chown -R refuge:refuge /home/refuge || true
chmod +x /usr/local/bin/refuge-browser || true

RefugeOS quick start
====================

What you should see after boot
------------------------------
- A dark desktop background.
- A bottom panel with menu, running apps, tray icons, clock, and system controls.
- Desktop shortcuts for the browser, library, Bible PDF, notes, office tools, maps, files, and terminal tools.

First things to do
------------------
1. Connect to Wi-Fi from the network icon.
2. Open Refuge Browser and confirm websites load.
3. Open RefugeLibrary and confirm the local Bible, notes, maps, and Kiwix folders are there.
4. Launch Xiphos, Kiwix, LibreOffice, and Maps from the desktop or applications menu.
5. Plug in a USB drive and confirm it appears in Files.

Where the important local content lives
---------------------------------------
/home/refuge/RefugeLibrary/

Browser home page
-----------------
file:///usr/share/refugeos/startpage/index.html

If the desktop ever looks blank
--------------------------------
The session is still booted if the mouse moves and the panel or tray is visible.
Open the menu or press Ctrl+Alt+T for a terminal, then run:

  pcmanfm --desktop --profile LXDE &
  lxpanel &
  nm-applet &

Logs for the graphical session are stored in:
- ~/.local/state/startx.log
- ~/.local/state/xsession.log

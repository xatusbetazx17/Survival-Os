# Start the graphical session automatically on tty1
if [[ -z "${DISPLAY:-}" && "$(tty)" == "/dev/tty1" ]]; then
  mkdir -p "$HOME/.local/state"
  clear
  exec startx >"$HOME/.local/state/startx.log" 2>&1
fi

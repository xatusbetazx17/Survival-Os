Desktop session troubleshooting
==============================

Symptom
-------
The live ISO boots, but the screen looks almost empty, with leftover boot text or only a dark background.

Cause
-----
That usually means X started, but the visible desktop helpers were not painted over the root window on that hardware or VM.

What this project now forces
----------------------------
- Openbox as the window manager.
- PCManFM as the desktop manager for icons and background.
- LXPanel as the panel and application menu.
- NetworkManager Applet for Wi-Fi control.
- startx output redirected to ~/.local/state/startx.log.

Quick manual recovery inside the live session
---------------------------------------------
Open a terminal and run:

  pcmanfm --desktop --profile LXDE &
  lxpanel &
  nm-applet &

If that recovers the interface, rebuild with this updated project tree.
